import React from "react";
import {
  Card,
  Image,
  Text,
  Badge,
  Button,
  Group,
  Container,
  SimpleGrid,
  Loader,
  Title,
} from "@mantine/core";
import { useFetchFilms } from "../../store/app.store"; // Import the hook
import Navbar from "../../components/Navbar";
import { useNavigate } from "react-router-dom";

const FilmsList = () => {
  const { data, isLoading, isError } = useFetchFilms();
  const navigate = useNavigate();

  if (!data) return null;

  if (isError) {
    return (
      <Container>
        <Text color="red">Failed to load films. Try again later.</Text>
      </Container>
    );
  }

  const sortedFilms = [...data].sort((a, b) => a.episode_id - b.episode_id);

  return (
    <>
      <Navbar />
      <main
        className="dashboardWrapper"
        style={{
          paddingLeft: window.innerWidth < 400 ? "16px" : "100px",
          paddingRight: window.innerWidth < 400 ? "16px" : "40px",
        }}
      >
        <Container size={"xl"}>
          <Title order={2} align="left" mt={"sm"}>
            Star Wars Films
          </Title>
          <Text fz="sm" mb="xl">
            Total Films: {sortedFilms.length}
          </Text>
          {isLoading ? (
            <div
              style={{
                width: "100%",
                height: "60vh",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <Loader color="blue" />
              <p>Loading</p>
            </div>
          ) : (
            <SimpleGrid
              cols={1}
              spacing="xl"
              breakpoints={[
                { minWidth: 768, cols: 2 },
                { minWidth: 1024, cols: 3 },
              ]}
            >
              {sortedFilms.map((film, index) => (
                <Card
                  key={film.episode_id}
                  shadow="sm"
                  padding="lg"
                  radius="md"
                  withBorder
                >
                  <Card.Section>
                    <Image
                      src={`https://images.unsplash.com/photo-1738571574302-3312deda0aa3?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D`}
                      height={160}
                      alt={film.title}
                    />
                  </Card.Section>

                  <Group position="apart" mt="md" mb="xs">
                    <Text weight={500} color="#5203fc">
                      {/* {film.title.length > 14
                        ? film.title.substring(0, 15) + ".."
                        : film.title} */}
                      {film.title}
                    </Text>
                    <Badge color="yellow" variant="light">
                      Episode {film.episode_id}
                    </Badge>
                  </Group>
                  <Group position="left" mt="md" mb="xs">
                    <Text size="sm" color="dimmed">
                      Directed by:
                    </Text>
                    <Text size="sm" color="">
                      {film.director}
                    </Text>
                  </Group>
                  <Group position="left" mt="xs" mb="xs">
                    <Text size="sm" color="dimmed">
                      Released on:
                    </Text>
                    <Text size="sm" color="">
                      {film.release_date}
                    </Text>
                  </Group>

                  <Button
                    variant="light"
                    color="green"
                    fullWidth
                    mt="md"
                    radius="md"
                    onClick={() => navigate(`/films/${index + 1}`)}
                  >
                    View Details
                  </Button>
                </Card>
              ))}
            </SimpleGrid>
          )}
        </Container>
      </main>
    </>
  );
};

export default FilmsList;
