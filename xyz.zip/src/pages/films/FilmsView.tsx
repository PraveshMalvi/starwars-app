import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom"; // ✅ Get ID from URL
import { Container, Loader, Text, Title, Tabs, List } from "@mantine/core";
import Navbar from "../../components/Navbar";
import CommonLoader from "../../components/Loader";

interface Film {
  episode_id: number;
  title: string;
  director: string;
  producer: string;
  release_date: string;
  opening_crawl: string;
  characters: string[];
  starships: string[];
  vehicles: string[];
  species: string[];
}

// ✅ Fetch Film by ID
const fetchFilm = async (id: string): Promise<Film> => {
  const response = await fetch(`https://swapi.dev/api/films/${id}/`);
  if (!response.ok) throw new Error("Failed to fetch film");
  return response.json();
};

// ✅ Fetch Additional Data (characters, starships, etc.)
const fetchData = async (urls: string[]) => {
  const requests = urls.map((url) => fetch(url).then((res) => res.json()));
  return Promise.all(requests);
};

const FilmsView = () => {
  const { id } = useParams<{ id: string }>(); // ✅ Get film ID from URL

  const { data, isLoading, isError } = useQuery<Film>({
    queryKey: ["film", id], // ✅ Unique queryKey with ID
    queryFn: () => fetchFilm(id!), // ✅ Ensure id is passed
    enabled: !!id, // ✅ Prevent running query with undefined ID
  });

  const [activeTab, setActiveTab] = useState<string>("characters"); // ✅ Ensure type is string

  // ✅ Fetch additional details when the tab is active
  const { data: characters, isLoading: loadingCharacters } = useQuery({
    queryKey: ["characters", data?.characters],
    queryFn: () => fetchData(data!.characters),
    enabled: activeTab === "characters" && !!data?.characters,
  });

  const { data: starships, isLoading: loadingStarships } = useQuery({
    queryKey: ["starships", data?.starships],
    queryFn: () => fetchData(data!.starships),
    enabled: activeTab === "starships" && !!data?.starships,
  });

  const { data: vehicles, isLoading: loadingVehicles } = useQuery({
    queryKey: ["vehicles", data?.vehicles],
    queryFn: () => fetchData(data!.vehicles),
    enabled: activeTab === "vehicles" && !!data?.vehicles,
  });

  const { data: species, isLoading: loadingSpecies } = useQuery({
    queryKey: ["species", data?.species],
    queryFn: () => fetchData(data!.species),
    enabled: activeTab === "species" && !!data?.species,
  });

  if (isError || !data) {
    return (
      <Container>
        <Text color="red"></Text>
      </Container>
    );
  }

  return (
    <>
      <Navbar />
      <main
        className="dashboardWrapper"
        style={{
          paddingLeft: window.innerWidth < 400 ? "16px" : "100px",
          paddingRight: window.innerWidth < 400 ? "16px" : "40px",
        }}
      >
        {isLoading ? (
          <CommonLoader />
        ) : (
          <Container>
            <Title order={2} align="center" mb="lg">
              {data.title} (Episode {data.episode_id})
            </Title>

            <Text align="center" size="sm" color="dimmed">
              Directed by {data.director} | Produced by {data.producer} |
              Released on {data.release_date}
            </Text>

            <Tabs
              value={activeTab}
              onTabChange={(value) => setActiveTab(value!)}
              mt="lg"
            >
              <Tabs.List>
                <Tabs.Tab value="characters">Characters</Tabs.Tab>
                <Tabs.Tab value="starships">Starships</Tabs.Tab>
                <Tabs.Tab value="vehicles">Vehicles</Tabs.Tab>
                <Tabs.Tab value="species">Species</Tabs.Tab>
              </Tabs.List>

              <Tabs.Panel value="characters">
                {loadingCharacters ? (
                  <CommonLoader />
                ) : (
                  <List spacing="sm" mt="md">
                    {characters?.map((char) => (
                      <List.Item key={char.name}>{char.name}</List.Item>
                    ))}
                  </List>
                )}
              </Tabs.Panel>

              <Tabs.Panel value="starships">
                {loadingStarships ? (
                  <CommonLoader />
                ) : (
                  <List spacing="sm" mt="md">
                    {starships?.map((ship) => (
                      <List.Item key={ship.name}>{ship.name}</List.Item>
                    ))}
                  </List>
                )}
              </Tabs.Panel>

              <Tabs.Panel value="vehicles">
                {loadingVehicles ? (
                  <CommonLoader />
                ) : (
                  <List spacing="sm" mt="md">
                    {vehicles?.map((vehicle) => (
                      <List.Item key={vehicle.name}>{vehicle.name}</List.Item>
                    ))}
                  </List>
                )}
              </Tabs.Panel>

              <Tabs.Panel value="species">
                {loadingSpecies ? (
                  <CommonLoader />
                ) : (
                  <List spacing="sm" mt="md">
                    {species?.map((specie) => (
                      <List.Item key={specie.name}>{specie.name}</List.Item>
                    ))}
                  </List>
                )}
              </Tabs.Panel>
            </Tabs>
          </Container>
        )}
      </main>
    </>
  );
};

export default FilmsView;
