import { create } from "zustand";
import { useQuery } from "@tanstack/react-query";

// ✅ Fake JWT token utility
const generateFakeJwt = (email: string) => {
  const header = { alg: "HS256", typ: "JWT" };
  const payload = { email, exp: Date.now() + 3600000 }; // 1 hour expiration
  const base64Encode = (obj: any) => btoa(JSON.stringify(obj)); // Base64 encoding

  return `${base64Encode(header)}.${base64Encode(payload)}`;
};

// ✅ User & Auth Store
interface User {
  email: string;
  token: string;
}

interface AuthState {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: JSON.parse(localStorage.getItem("user") || "null"),

  login: async (email, password) => {
    const hardcodedUser = { email: "admin@example.com", password: "admin123" };

    if (email === hardcodedUser.email && password === hardcodedUser.password) {
      const token = generateFakeJwt(email);
      const user = { email, token };
      localStorage.setItem("user", JSON.stringify(user));
      set({ user });
      return true;
    }
    return false;
  },

  logout: () => {
    localStorage.removeItem("user");
    set({ user: null });
  },
}));

// ✅ User & Data Interfaces
export interface UserData {
  id: number;
  name: string;
  email: string;
  company: { name: string };
  address: {
    city: string;
    geo: { lat: string; lng: string };
  };
}

export interface PlanetData {
  name: string;
  climate: string;
  terrain: string;
  orbital_period: string;
  population: string;
  rotation_period: string;
}

export interface FilmData {
  title: string;
  episode_id: number;
  director: string;
  release_date: string;
  opening_crawl: string
}

// ✅ App Store
interface AppState {
  users: UserData[];
  planets: PlanetData[];
  films: FilmData[];
  setUsers: (users: UserData[]) => void;
  setPlanets: (planets: PlanetData[]) => void;
  setFilms: (films: FilmData[]) => void;
}

export const useAppStore = create<AppState>((set) => ({
  users: [],
  planets: [],
  films: [],
  setUsers: (users) => set({ users }),
  setPlanets: (planets) => set({ planets }),
  setFilms: (films) => set({ films }),
}));

// ✅ Fetch API Functions
const fetchUsers = async (): Promise<UserData[]> => {
  const response = await fetch("https://jsonplaceholder.typicode.com/users");
  if (!response.ok) throw new Error("Failed to fetch users");
  return response.json();
};

const fetchPlanets = async (): Promise<PlanetData[]> => {
  const response = await fetch("https://swapi.dev/api/planets");
  if (!response.ok) throw new Error("Failed to fetch planets");
  const data = await response.json();
  return data.results;
};

const fetchFilms = async (): Promise<FilmData[]> => {
  const response = await fetch("https://swapi.dev/api/films");
  if (!response.ok) throw new Error("Failed to fetch films");
  const data = await response.json();
  return data.results;
};

// ✅ Custom Hooks to Fetch & Store Data
export const useFetchUsers = () => {
  const setUsers = useAppStore((state) => state.setUsers);

  return useQuery({
    queryKey: ["users"],
    queryFn: fetchUsers,
    onSuccess: (data) => setUsers(data),
  });
};

export const useFetchPlanets = () => {
  const setPlanets = useAppStore((state) => state.setPlanets);

  return useQuery({
    queryKey: ["planets"],
    queryFn: fetchPlanets,
    onSuccess: (data) => setPlanets(data),
  });
};

export const useFetchFilms = () => {
  const setFilms = useAppStore((state) => state.setFilms);

  return useQuery({
    queryKey: ["films"],
    queryFn: fetchFilms,
    onSuccess: (data) => setFilms(data),
  });
};
