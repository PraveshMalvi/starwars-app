import { useState } from "react";
import { Link, useLocation } from "react-router-dom"; // Import Link
import {
  IconArrowRight,
  IconArrowLeft,
  IconLogout,
  IconFunctionFilled,
  IconChartHistogram,
  IconPlanet,
  IconMovie,
  IconUsersGroup,
} from "@tabler/icons-react";
import { Group, Menu } from "@mantine/core";
import { IconSettings, IconPhoto } from "@tabler/icons-react";
import classes from "../components/Navbar.module.css";
import { useAuthStore } from "../store/app.store";

const data = [
  { link: "/dashboard", label: "Dashboard", icon: IconChartHistogram },
  { link: "/planets", label: "Planets", icon: IconPlanet },
  { link: "/films", label: "Films", icon: IconMovie },
  { link: "/people", label: "Residents", icon: IconUsersGroup },
];

function Navbar() {
  const [active, setActive] = useState("Dashboard");
  const [toggle, setToggle] = useState(true);
  const logout = useAuthStore((state) => state.logout);
  const {pathname} = useLocation()

  const links = data.map((item) => (
    <Link
      to={item.link} // Use `to` instead of `href`
      className={classes.link}
      data-active={pathname.includes(item.link) ? "true" : undefined}
      key={item.label}
      style={{
        justifyContent: toggle ? "center" : "left",
        gap: toggle ? 0 : "10px",
      }}
    >
      <item.icon className={classes.linkIcon} stroke={1.5} />
      <span>{!toggle ? item.label : ""}</span>
    </Link>
  ));

  return (
    <>
      <nav className={classes.navbar}>
        <Menu shadow="md" width={200}>
          <Menu.Target>
            <div className={classes.userToggle}>
              <div className={classes.avatar}>
                <p style={{ color: "#ffffff" }}>A</p>
              </div>
              <p>Hi, Admin</p>
            </div>
          </Menu.Target>

          <Menu.Dropdown>
            <Menu.Item icon={<IconSettings size={14} />}>Profile</Menu.Item>
            <Menu.Item icon={<IconPhoto size={14} />}>Gallery</Menu.Item>
          </Menu.Dropdown>
        </Menu>
      </nav>
      <aside
        className={classes.sidebar}
        style={{
          width: !toggle ? "250px" : "80px",
          position: "fixed",
          top: 0,
          left: window.innerWidth < 400 ? "-100px" : 0,
        }}
      >
        <div onClick={() => setToggle(!toggle)} className={classes.toggleIcon}>
          {toggle ? (
            <IconArrowRight color="#5203fc" size={28} />
          ) : (
            <IconArrowLeft color="#5203fc" size={28} />
          )}
        </div>
        <div className={classes.sidebarMain}>
          <Group className={classes.sidebarHeader}>
            <div>
              <IconFunctionFilled color="#000000" size={48} />
            </div>
          </Group>
          <div style={{ display: "flex", flexDirection: "column", gap: "5px" }}>
            {links}
          </div>
        </div>

        <div className={classes.footer}>
          <button
            className={classes.link} // Use button instead of anchor tag
            onClick={logout}
            style={{ background: "none", border: "none", cursor: "pointer" }}
          >
            <IconLogout className={classes.linkIcon} stroke={1.5} />
            <span>{!toggle ? "Logout" : ""}</span>
          </button>
        </div>
      </aside>
    </>
  );
}

export default Navbar;
