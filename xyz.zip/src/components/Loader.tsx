import { Loader } from "@mantine/core";
import React from "react";

const CommonLoader = () => {
  return (
    <div
      style={{
        width: "100%",
        height: "50vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Loader color="blue" />
      <p>Loading</p>
    </div>
  );
};

export default CommonLoader;
